<?php

    session_start();

    // Renvoi vers contrôleur principal
    require_once('controleur/controleur.php');

?>